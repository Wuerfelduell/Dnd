extends SceneTree

func _initialize():
	var catalog_file = FileAccess.open("res://asset_catalog.json", FileAccess.READ)
	var catalog = JSON.parse_string(catalog_file.get_as_text())
	var count = 0
	for asset in catalog:
		var resource = load("res://" + asset.path)
		if not resource is PackedScene:
			push_error("Not a PackedScene: " + asset.path)
			quit(1)
			return
		var instance = resource.instantiate()
		if instance == null:
			push_error("Cannot instantiate: " + asset.path)
			quit(1)
			return
		instance.free()
		count += 1
	for filename in ["Dungeon_Courtyard", "Forest_Camp"]:
		var demo = load("res://scenes/" + filename + ".tscn").instantiate()
		demo.free()
	for asset in catalog:
		if asset.source == "custom_grid":
			var wrapper = load("res://scenes/collision_ready/" + asset.name + ".tscn").instantiate()
			if wrapper == null:
				quit(1)
				return
			wrapper.free()
	print("PASS: %d GLB models, 2 demo scenes and 21 collision scenes loaded and instantiated." % count)
	quit()
