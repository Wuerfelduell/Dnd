extends Node3D
const Armor = preload("res://scripts/equip_armor.gd")
const FX = preload("res://scripts/billboard_fx.gd")
var clock: float = 0.0
var selected: int = 0
var armored: Node3D
var variants = ["leather", "chainmail", "plate"]

func _ready() -> void:
	var camera = Camera3D.new()
	add_child(camera)
	camera.position = Vector3(6, 6, 9)
	camera.look_at(Vector3(0, 1, 0))
	var light = DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-55, -25, 0)
	light.light_energy = 1.7
	add_child(light)
	var world = WorldEnvironment.new()
	world.environment = Environment.new()
	world.environment.background_mode = Environment.BG_COLOR
	world.environment.background_color = Color("182238")
	world.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world.environment.ambient_light_color = Color.WHITE
	world.environment.ambient_light_energy = 0.65
	add_child(world)
	var table = load("res://models/shop/merchant_wares_table.glb").instantiate()
	table.position = Vector3(-2.5, 0, 0)
	add_child(table)
	for i in range(3):
		var actor = load("res://models/demo/" + ["Knight", "Mage", "Rogue"][i] + ".glb").instantiate()
		actor.position = Vector3(i * 1.8 - 0.5, 0, 0)
		add_child(actor)
		Armor.equip(actor, load("res://models/armor/armor_" + variants[i] + ".glb"))
		for node in Armor.descendants(actor):
			if node is AnimationPlayer and node.has_animation("Idle"):
				node.play("Idle")
		if i == 0:
			armored = actor
	var label = Label.new()
	label.text = "KayKit armor: leather / chainmail / plate\nSpace or tap: change Knight armor | particle effects loop"
	label.position = Vector2(20, 20)
	add_child(label)

func _input(event: InputEvent) -> void:
	if (event is InputEventKey and event.pressed and event.keycode == KEY_SPACE) or (event is InputEventScreenTouch and event.pressed):
		selected = (selected + 1) % 3
		Armor.equip(armored, load("res://models/armor/armor_" + variants[selected] + ".glb"))

func _process(delta: float) -> void:
	clock += delta
	if clock >= 1.2:
		clock = 0
		for i in range(6):
			var effect = FX.new()
			effect.sheet = load("res://effects/" + ["hit_sparks", "dust_impact", "fireball_explosion", "frost_shatter", "poison_cloud", "heal_sparkles"][i] + ".png")
			effect.position = Vector3(i * 1.4 - 3.5, 0.8, 2.5)
			add_child(effect)
