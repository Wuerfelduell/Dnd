class_name BillboardFX
extends Sprite3D

@export var sheet: Texture2D
@export var frames_per_second: float = 24.0
@export var effect_size_m: float = 1.28
var elapsed: float = 0.0

func _ready() -> void:
	texture = sheet
	hframes = 4
	vframes = 4
	billboard = BaseMaterial3D.BILLBOARD_ENABLED
	shaded = false
	pixel_size = effect_size_m / 128.0
	frame = 0

func _process(delta: float) -> void:
	elapsed += delta
	var next_frame = int(elapsed * frames_per_second)
	if next_frame >= 16:
		queue_free()
	else:
		frame = next_frame
