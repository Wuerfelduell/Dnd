extends SceneTree
const Armor = preload("res://scripts/equip_armor.gd")
func _initialize() -> void:
	call_deferred("verify")
func verify() -> void:
	var cat = JSON.parse_string(FileAccess.get_file_as_string("res://catalog.json"))
	for entry in cat.models:
		var scene = load("res://" + entry.path)
		assert(scene is PackedScene, entry.path)
		var instance = scene.instantiate()
		assert(instance != null)
		instance.free()
	var combos = 0
	var reference = load("res://models/armor/armor_plate.glb").instantiate()
	var reference_skeleton: Skeleton3D
	var reference_body: MeshInstance3D
	for node in Armor.descendants(reference):
		if node is Skeleton3D:
			reference_skeleton = node
		if node is MeshInstance3D and node.name == &"Knight_Body":
			reference_body = node
	for hero in ["Knight", "Mage", "Rogue"]:
		var actor = load("res://models/demo/" + hero + ".glb").instantiate()
		root.add_child(actor)
		for node in Armor.descendants(actor):
			if node is Skeleton3D:
				for bind in range(reference_body.skin.get_bind_count()):
					var bone_name = reference_body.skin.get_bind_name(bind)
					var i = reference_skeleton.find_bone(bone_name) if bone_name != &"" else reference_body.skin.get_bind_bone(bind)
					var idx = node.find_bone(reference_skeleton.get_bone_name(i))
					assert(idx >= 0)
					assert(node.get_bone_global_rest(idx).is_equal_approx(reference_skeleton.get_bone_global_rest(i)), "Rest mismatch: " + hero + " / " + str(reference_skeleton.get_bone_name(i)))
		for variant in ["leather", "chainmail", "plate", "leather"]:
			var equipped = Armor.equip(actor, load("res://models/armor/armor_" + variant + ".glb"))
			assert(equipped != null, hero + " / " + variant)
			assert(equipped.skin.get_bind_count() == 41)
			var skeleton = equipped.get_node(equipped.skeleton) as Skeleton3D
			assert(skeleton != null)
			for i in range(equipped.skin.get_bind_count()):
				assert(equipped.skin.get_bind_bone(i) >= 0)
				assert(equipped.skin.get_bind_bone(i) < skeleton.get_bone_count())
			for node in Armor.descendants(actor):
				if node is AnimationPlayer:
					assert(node.has_animation("Walking_A"))
					node.play("Walking_A")
					node.advance(0.25)
			combos += 1
			await process_frame
		actor.free()
	reference.free()
	for fx in cat.effects:
		var texture = load("res://" + cat.effects[fx].path) as Texture2D
		assert(texture.get_size() == Vector2(512, 512))
	for icon in cat.icons:
		assert((load("res://icons/" + icon) as Texture2D).get_size() == Vector2(128, 128))
	for sound in cat.sounds:
		assert(load("res://sounds/" + sound) is AudioStreamWAV)
	print("PASS: 20 assets, 18 icons, 6 FX sheets, 12 WAVs; 12 armor swaps with mapped skin + walking animations on Knight/Mage/Rogue.")
	quit()
