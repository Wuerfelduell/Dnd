extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var file = FileAccess.open("res://character_catalog.json", FileAccess.READ)
	var catalog = JSON.parse_string(file.get_as_text())
	var count = 0
	for asset in catalog:
		var model = load("res://" + asset.path)
		if not model is PackedScene:
			push_error("Cannot load: " + asset.path)
			quit(1)
			return
		var node = model.instantiate()
		if node == null:
			quit(1)
			return
		node.free()
		count += 1
	var dir = DirAccess.open("res://scenes/characters")
	var checked = 0
	for filename in dir.get_files():
		if not filename.ends_with(".tscn"):
			continue
		var actor = load("res://scenes/characters/" + filename).instantiate()
		root.add_child(actor)
		if actor.right_hand_equipment != null and actor.character_skeleton.find_bone("handslot.r") < 0:
			push_error(filename + " missing right-hand equipment bone")
			quit(1)
			return
		for action in ["idle", "walk", "run", "attack", "hit", "death"]:
			if not actor.play_action(action):
				push_error(filename + " missing action: " + action)
				quit(1)
				return
			actor.animation_player.advance(0.2)
		print("PASS actor/actions: ", filename)
		root.remove_child(actor)
		actor.free()
		checked += 1
	print("PASS: %d models and %d prepared actor scenes." % [count, checked])
	quit()
