extends CharacterBody3D

@export var allowed_equipment: PackedStringArray = []
@export var animation_family: String = "kaykit"
@export var right_hand_equipment: PackedScene
@export var left_hand_equipment: PackedScene
var animation_player: AnimationPlayer
var character_skeleton: Skeleton3D

const EQUIPMENT_NAMES = ["1H_Sword_Offhand", "Badge_Shield", "Rectangle_Shield", "Round_Shield", "Spike_Shield", "1H_Sword", "2H_Sword", "Knife_Offhand", "1H_Crossbow", "2H_Crossbow", "Knife", "Throwable", "Spellbook", "Spellbook_open", "1H_Wand", "2H_Staff", "1H_Axe_Offhand", "Barbarian_Round_Shield", "1H_Axe", "2H_Axe", "Mug"]

func _ready() -> void:
	configure_visual($Visual)
	attach_equipment(right_hand_equipment, "handslot.r")
	attach_equipment(left_hand_equipment, "handslot.l")
	play_action("idle")

func configure_visual(node: Node) -> void:
	if node is Skeleton3D:
		character_skeleton = node
	if node is AnimationPlayer:
		animation_player = node
	if node is MeshInstance3D and str(node.name) in EQUIPMENT_NAMES:
		node.visible = str(node.name) in allowed_equipment
	for child in node.get_children():
		configure_visual(child)

func find_animation(candidates: Array) -> StringName:
	if animation_player == null:
		return &""
	for candidate in candidates:
		for clip in animation_player.get_animation_list():
			var short_name = str(clip).split("|")[-1]
			if short_name == candidate or short_name.ends_with("/" + str(candidate)):
				return clip
	return &""

func play_action(action: String) -> bool:
	var choices: Array = []
	match action:
		"idle": choices = ["Idle", "Unarmed_Idle"]
		"walk": choices = ["Walking_A", "Walk"]
		"run": choices = ["Running_A", "Run", "Gallop"]
		"attack": choices = ["1H_Melee_Attack_Chop", "Attack"]
		"ranged": choices = ["1H_Ranged_Shoot", "2H_Ranged_Shoot", "Attack"]
		"cast": choices = ["Spellcast_Shoot", "Spellcasting"]
		"hit": choices = ["Hit_A", "HitRecieve", "Idle_HitReact_Left"]
		"death": choices = ["Death_A", "Death"]
		_: return false
	var clip = find_animation(choices)
	if clip == &"":
		return false
	animation_player.get_animation(clip).loop_mode = Animation.LOOP_LINEAR if action in ["idle", "walk", "run"] else Animation.LOOP_NONE
	animation_player.play(clip, 0.15)
	return true

func attach_equipment(scene: PackedScene, bone_name: String) -> void:
	if scene == null or character_skeleton == null:
		return
	if character_skeleton.find_bone(bone_name) < 0:
		return
	var socket = BoneAttachment3D.new()
	socket.bone_name = bone_name
	character_skeleton.add_child(socket)
	socket.add_child(scene.instantiate())
