extends Node3D

func _ready() -> void:
	var layer = CanvasLayer.new()
	add_child(layer)
	var panel = PanelContainer.new()
	panel.position = Vector2(12, 12)
	layer.add_child(panel)
	var box = VBoxContainer.new()
	panel.add_child(box)
	var label = Label.new()
	label.text = "DnD Figuren — Animation testen"
	box.add_child(label)
	var row = HBoxContainer.new()
	box.add_child(row)
	for action in ["idle", "walk", "run", "attack", "ranged", "cast", "hit", "death"]:
		var button = Button.new()
		button.text = action.capitalize()
		button.custom_minimum_size = Vector2(72, 44)
		button.pressed.connect(show_action.bind(action))
		row.add_child(button)

func show_action(action: String) -> void:
	for actor in get_children():
		if actor.has_method("play_action"):
			if not actor.play_action(action):
				actor.play_action("idle")
