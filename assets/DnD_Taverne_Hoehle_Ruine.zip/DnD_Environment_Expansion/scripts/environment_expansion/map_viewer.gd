extends Node3D
@export var title: String = "Environment"
var angle: float = 35.0
var zoom: float = 32.0

func _ready() -> void:
	var layer = CanvasLayer.new()
	add_child(layer)
	var panel = PanelContainer.new()
	panel.position = Vector2(12, 12)
	layer.add_child(panel)
	var column = VBoxContainer.new()
	panel.add_child(column)
	var label = Label.new()
	label.text = title
	column.add_child(label)
	var row = HBoxContainer.new()
	column.add_child(row)
	for text in ["Links", "Rechts", "Zoom +", "Zoom -"]:
		var button = Button.new()
		button.text = text
		button.custom_minimum_size = Vector2(85, 44)
		button.pressed.connect(change_view.bind(text))
		row.add_child(button)
	var scenes_row = HBoxContainer.new()
	column.add_child(scenes_row)
	for entry in [["Taverne", "Tavern"], ["Höhle", "Cave"], ["Ruine", "Ruins"]]:
		var scene_button = Button.new()
		scene_button.text = entry[0]
		scene_button.custom_minimum_size = Vector2(112, 44)
		scene_button.pressed.connect(switch_scene.bind(entry[1]))
		scenes_row.add_child(scene_button)
	update_camera()

func switch_scene(scene_name: String) -> void:
	get_tree().change_scene_to_file("res://scenes/environment_expansion/" + scene_name + ".tscn")

func change_view(action: String) -> void:
	match action:
		"Links": angle -= 30.0
		"Rechts": angle += 30.0
		"Zoom +": zoom = maxf(16.0, zoom - 3.0)
		"Zoom -": zoom = minf(50.0, zoom + 3.0)
	update_camera()

func update_camera() -> void:
	var radians = deg_to_rad(angle)
	$Camera3D.position = Vector3(sin(radians) * 28.0, 27.0, cos(radians) * 28.0)
	$Camera3D.look_at(Vector3.ZERO)
	$Camera3D.size = zoom
