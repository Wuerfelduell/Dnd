extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var file = FileAccess.open("res://asset_catalog.json", FileAccess.READ)
	var catalog = JSON.parse_string(file.get_as_text())
	var count = 0
	for asset in catalog:
		var model = load("res://" + asset.path)
		if not model is PackedScene:
			push_error("Cannot load " + asset.path)
			quit(1)
			return
		var node = model.instantiate()
		node.free()
		count += 1
	var dir = DirAccess.open("res://scenes/environment_expansion/collision_ready")
	var collision_count = 0
	for filename in dir.get_files():
		if not filename.ends_with(".tscn"):
			continue
		var object = load("res://scenes/environment_expansion/collision_ready/" + filename).instantiate()
		var shape = object.get_node("StaticBody3D/CollisionShape3D").shape
		if shape.get_faces().size() == 0:
			push_error("Empty collision: " + filename)
			quit(1)
			return
		object.free()
		collision_count += 1
	for name in ["Tavern", "Cave", "Ruins"]:
		var scene = load("res://scenes/environment_expansion/" + name + ".tscn").instantiate()
		root.add_child(scene)
		scene.change_view("Links")
		scene.change_view("Zoom +")
		var camera = scene.get_node("Camera3D")
		if not camera.position.is_finite():
			quit(1)
			return
		print("PASS scene/camera: ", name)
		root.remove_child(scene)
		scene.free()
	print("PASS: %d models, %d collision scenes and 3 map scenes." % [count, collision_count])
	quit()
