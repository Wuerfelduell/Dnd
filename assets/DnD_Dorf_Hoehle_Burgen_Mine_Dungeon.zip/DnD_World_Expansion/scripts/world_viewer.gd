extends Node3D
@export var theme: String = "castle_intact"
var angle: float = 0.65
var zoom: float = 37.0
var center = Vector3.ZERO
var drag: bool = false
@onready var camera: Camera3D = $Camera3D
func _ready() -> void:
	var world = WorldEnvironment.new()
	world.environment = Environment.new()
	world.environment.background_mode = Environment.BG_COLOR
	world.environment.background_color = Color("1c2932")
	world.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world.environment.ambient_light_color = Color(0.8, 0.85, 0.87)
	world.environment.ambient_light_energy = 0.7
	add_child(world)
	var layer = CanvasLayer.new()
	add_child(layer)
	var box = VBoxContainer.new()
	box.position = Vector2(14, 14)
	layer.add_child(box)
	var row = HBoxContainer.new()
	box.add_child(row)
	for key in ["village", "cave", "castle_intact", "castle_ruined", "mine", "dungeon"]:
		var button = Button.new()
		button.text = {"village":"Dorf", "cave":"Höhle", "castle_intact":"Burg", "castle_ruined":"Burgruine", "mine":"Mine", "dungeon":"Dungeon"}[key]
		button.custom_minimum_size = Vector2(100, 48)
		button.pressed.connect(change_world.bind(key))
		row.add_child(button)
	var controls = HBoxContainer.new()
	box.add_child(controls)
	for action in ["Links", "Rechts", "+", "-"]:
		var button = Button.new()
		button.text = action
		button.custom_minimum_size = Vector2(70, 44)
		button.pressed.connect(control.bind(action))
		controls.add_child(button)
	update_camera()
func change_world(key: String) -> void:
	get_tree().change_scene_to_file("res://scenes/" + key + ".tscn")
func control(action: String) -> void:
	match action:
		"Links": angle -= 0.22
		"Rechts": angle += 0.22
		"+": zoom = max(10.0, zoom - 4.0)
		"-": zoom = min(75.0, zoom + 4.0)
	update_camera()
func update_camera() -> void:
	camera.size = zoom
	camera.position = center + Vector3(sin(angle) * 40, 34, cos(angle) * 40)
	camera.look_at(center)
func pan(delta: Vector2) -> void:
	center += (-camera.global_basis.x * delta.x + camera.global_basis.y * delta.y) * zoom / 720.0
	center.y = 0
	update_camera()
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			drag = event.pressed
		if event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			control("+")
		if event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			control("-")
	elif event is InputEventMouseMotion and drag:
		pan(event.relative)
	elif event is InputEventScreenDrag:
		pan(event.relative)
