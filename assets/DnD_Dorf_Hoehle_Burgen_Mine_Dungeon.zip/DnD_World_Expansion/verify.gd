extends SceneTree
func _initialize() -> void:
	call_deferred("verify")
func verify() -> void:
	var assets = JSON.parse_string(FileAccess.get_file_as_string("res://catalog.json"))
	var solid_count = 0
	for asset in assets:
		var packed = load("res://" + asset.path)
		assert(packed is PackedScene, asset.path)
		var model = packed.instantiate()
		assert(model != null)
		model.free()
		var scene = load("res://" + asset.scene).instantiate()
		assert(scene != null)
		if asset.collision_ready:
			assert(scene.get_node("Body/CollisionShape3D").shape.get_faces().size() == asset.triangles * 3)
			solid_count += 1
		scene.free()
	for key in ["village", "cave", "castle_intact", "castle_ruined", "mine", "dungeon"]:
		var scene = load("res://scenes/" + key + ".tscn").instantiate()
		root.add_child(scene)
		for i in range(3):
			await physics_frame
		var probe = Vector3(0, 10, -6) if key != "village" else Vector3(0, 10, 0)
		var query = PhysicsRayQueryParameters3D.create(probe, probe - Vector3(0, 12, 0))
		assert(not scene.get_world_3d().direct_space_state.intersect_ray(query).is_empty(), "No walkable support: " + key)
		root.remove_child(scene)
		scene.free()
	# Open mine shaft has collision around the rim and a genuinely empty center.
	var shaft = load("res://scenes/assets/mine_shaft_open.tscn").instantiate()
	root.add_child(shaft)
	await physics_frame
	await physics_frame
	var space = shaft.get_world_3d().direct_space_state
	assert(space.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(0, 2, 0), Vector3(0, -2, 0))).is_empty())
	assert(not space.intersect_ray(PhysicsRayQueryParameters3D.create(Vector3(1.65, 2, 0), Vector3(1.65, -2, 0))).is_empty())
	shaft.free()
	print("PASS: 102 GLBs, %d collision wrappers, 6 maps; floor probes and open mine-shaft collision verified." % solid_count)
	quit()
