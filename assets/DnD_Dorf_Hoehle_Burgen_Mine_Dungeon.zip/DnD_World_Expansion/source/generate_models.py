from pathlib import Path
import ast, math, json, struct, random, copy, io, shutil
import numpy as np
from PIL import Image, ImageDraw, ImageFont
R = Path('DnD_World_Expansion')
R.mkdir(exist_ok=True)
parts = []
assets = []
wood = (0.35, 0.2, 0.105)
woodlight = (0.55, 0.36, 0.19)
wooddark = (0.16, 0.12, 0.095)
stone = (0.38, 0.42, 0.43)
stonebright = (0.53, 0.54, 0.49)
plaster = (0.68, 0.63, 0.49)
earth = (0.36, 0.29, 0.19)
grass = (0.27, 0.34, 0.2)
moss = (0.2, 0.29, 0.14)
roof = (0.32, 0.2, 0.16)
iron = (0.19, 0.22, 0.25)
gold = (0.64, 0.43, 0.14)
cyan = (0.08, 0.47, 0.57)
purple = (0.51, 0.22, 0.76)
orange = (1, 0.35, 0.04)
cream = (0.85, 0.79, 0.64)
black = (0.075, 0.065, 0.06)
red = (0.42, 0.17, 0.13)

def begin():
    parts.clear()

def poly(v, faces, color):
    v = np.array(v, float)
    cent = v.mean(0)
    pts = []
    ns = []
    for face in faces:
        for k in range(1, len(face) - 1):
            inds = [face[0], face[k], face[k + 1]]
            t = v[inds]
            n = np.cross(t[1] - t[0], t[2] - t[0])
            ln = np.linalg.norm(n)
            if ln < 1e-08:
                continue
            if n @ (t.mean(0) - cent) < 0:
                t = t[[0, 2, 1]]
                n = -n
            n = n / ln
            pts.extend(t)
            ns.extend([n] * 3)
    parts.append((np.array(pts, dtype='<f4'), np.array(ns, dtype='<f4'), color))

def box(c, s, color, angle=0, axis='y'):
    c = np.array(c)
    s = np.array(s) / 2
    v = np.array([[x, y, z] for z in [-1, 1] for y in [-1, 1] for x in [-1, 1]]) * s
    a = math.radians(angle)
    co = math.cos(a)
    si = math.sin(a)
    M = np.array([[co, 0, si], [0, 1, 0], [-si, 0, co]]) if axis == 'y' else np.array([[1, 0, 0], [0, co, -si], [0, si, co]]) if axis == 'x' else np.array([[co, -si, 0], [si, co, 0], [0, 0, 1]])
    poly(v @ M.T + c, [[1, 5, 7, 3], [4, 0, 2, 6], [2, 3, 7, 6], [4, 5, 1, 0], [5, 4, 6, 7], [0, 1, 3, 2]], color)

def cyl(c, r0, r1, h, color, n=8, tilt=0):
    v = []
    for y, r in [(-h / 2, r0), (h / 2, r1)]:
        for i in range(n):
            a = 2 * math.pi * i / n
            v.append([math.cos(a) * r, y, math.sin(a) * r])
    v = np.array(v)
    a = math.radians(tilt)
    M = np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])
    v = v @ M.T + np.array(c)
    faces = [list(range(n)), list(range(n, 2 * n))] + [[i, (i + 1) % n, (i + 1) % n + n, i + n] for i in range(n)]
    poly(v, faces, color)

def rock(c, s, color, seed=1):
    rng = random.Random(seed)
    n = 7
    v = [[0, -s[1] / 2, 0], [0, s[1] / 2, 0]]
    for i in range(n):
        a = 2 * math.pi * i / n
        r = rng.uniform(0.83, 1.14)
        v.append([math.cos(a) * s[0] / 2 * r, rng.uniform(-0.18, 0.18) * s[1], math.sin(a) * s[2] / 2 * r])
    faces = []
    for i in range(n):
        faces.extend([[0, 2 + i, 2 + (i + 1) % n], [1, 2 + (i + 1) % n, 2 + i]])
    poly(np.array(v) + c, faces, color)

def arch(width=4, height=3.4, depth=0.6, color=stone, broken=False):
    inner = width / 2 - 0.45
    outer = width / 2
    spring = height - outer
    for x in [-width / 2 + 0.225, width / 2 - 0.225]:
        box((x, spring / 2, 0), (0.45, spring, depth), color)
    for i in range(10):
        if broken and i in [3, 4]:
            continue
        a = math.pi * i / 10
        b = math.pi * (i + 1) / 10
        v = []
        for z in [-depth / 2, depth / 2]:
            for r, t in [(inner, a), (outer, a), (outer, b), (inner, b)]:
                v.append([r * math.cos(t), spring + r * math.sin(t), z])
        poly(v, [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]], color)

def read(p):
    b = p.read_bytes()
    n = struct.unpack_from('<I', b, 12)[0]
    return (json.loads(b[20:20 + n]), bytearray(b[28 + n:]))

def write(p, j, b):
    b += b'\x00' * (-len(b) % 4)
    j['buffers'] = [{'byteLength': len(b)}]
    jb = json.dumps(j, separators=(',', ':')).encode()
    jb += b' ' * (-len(jb) % 4)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(struct.pack('<III', 1179937895, 2, 28 + len(jb) + len(b)) + struct.pack('<II', len(jb), 1313821514) + jb + struct.pack('<II', len(b), 5130562) + b)

def blank(name):
    return ({'asset': {'version': '2.0', 'generator': 'Original DnD animated cast'}, 'scene': 0, 'scenes': [{'name': name, 'nodes': [0]}], 'nodes': [{'name': name, 'children': []}], 'meshes': [], 'materials': [], 'bufferViews': [], 'accessors': [], 'animations': []}, bytearray())

def accessor(j, b, arr, typ):
    arr = np.asarray(arr, dtype='<f4')
    while len(b) % 4:
        b.append(0)
    v = len(j['bufferViews'])
    j['bufferViews'].append({'buffer': 0, 'byteOffset': len(b), 'byteLength': arr.nbytes})
    b.extend(arr.tobytes())
    a = {'bufferView': v, 'componentType': 5126, 'count': len(arr), 'type': typ}
    if typ in ['VEC3', 'SCALAR']:
        a.update(min=arr.min(0).tolist() if typ == 'VEC3' else [float(arr.min())], max=arr.max(0).tolist() if typ == 'VEC3' else [float(arr.max())])
    j['accessors'].append(a)
    return len(j['accessors']) - 1

def save(name, category, role='decoration', label=None):
    j, b = blank(name)
    groups = {}
    for p, n, c in parts:
        groups.setdefault(c, []).append((p, n))
    prims = []
    for c, g in groups.items():
        p = np.concatenate([x[0] for x in g])
        n = np.concatenate([x[1] for x in g])
        pa = accessor(j, b, p, 'VEC3')
        na = accessor(j, b, n, 'VEC3')
        mat = {'name': name + '_material_' + str(len(j['materials'])), 'pbrMetallicRoughness': {'baseColorFactor': [*c, 1], 'roughnessFactor': 0.85, 'metallicFactor': 0.3 if c == iron else 0}}
        if category == 'river' and c == cyan:
            mat['pbrMetallicRoughness']['roughnessFactor'] = 0.23
        j['materials'].append(mat)
        prims.append({'attributes': {'POSITION': pa, 'NORMAL': na}, 'material': len(j['materials']) - 1})
    j['meshes'] = [{'name': name, 'primitives': prims}]
    j['nodes'][0]['mesh'] = 0
    p = R / 'assets/village' / category / (name + '.glb')
    write(p, j, b)
    xyz = np.concatenate([x[0] for x in parts])
    assets.append({'id': name, 'label': label or name.replace('_', ' '), 'category': category, 'path': p.relative_to(R).as_posix(), 'role': role, 'triangles': len(xyz) // 3, 'materials': len(prims), 'bounds_min': xyz.min(0).tolist(), 'bounds_max': xyz.max(0).tolist(), 'size_m': np.ptp(xyz, axis=0).tolist()})

def rod(a, b, r, color=wood, n=6):
    a = np.array(a, float)
    b = np.array(b, float)
    direction = b - a
    direction /= np.linalg.norm(direction)
    u = np.cross(direction, [0, 1, 0] if abs(direction[1]) < 0.9 else [1, 0, 0])
    u /= np.linalg.norm(u)
    v = np.cross(direction, u)
    verts = [q + r * (u * math.cos(t) + v * math.sin(t)) for q in [a, b] for t in np.linspace(0, 2 * math.pi, n, endpoint=False)]
    poly(verts, [list(range(n)), list(range(n, 2 * n))] + [[i, (i + 1) % n, (i + 1) % n + n, i + n] for i in range(n)], color)

def stones(seed=1, count=8, span=(3, 3), offset=(0, 0, 0)):
    rng = random.Random(seed)
    for i in range(count):
        x = rng.uniform(-span[0] / 2, span[0] / 2) + offset[0]
        z = rng.uniform(-span[1] / 2, span[1] / 2) + offset[2]
        h = rng.uniform(0.1, 0.32)
        rock((x, offset[1] + h / 2, z), (rng.uniform(0.2, 0.6), h, rng.uniform(0.2, 0.55)), stone, i + seed)

def bag(c=(0, 0, 0), color=woodlight):
    x, y, z = c
    cyl((x, y + 0.25, z), 0.21, 0.26, 0.5, color, 8)
    cyl((x, y + 0.55, z), 0.26, 0.09, 0.1, color, 8)
    cyl((x, y + 0.615, z), 0.1, 0.13, 0.03, cream, 8)

def barrel(c=(0, 0, 0), broken=False):
    x, y, z = c
    if not broken:
        cyl((x, y + 0.47, z), 0.36, 0.4, 0.94, wood, 10)
    else:
        for i in range(7):
            t = i * math.pi / 5
            box((x + 0.34 * math.cos(t), y + 0.35, z + 0.34 * math.sin(t)), (0.14, 0.7, 0.07), wood, -t * 180 / math.pi)
    for yc in [0.16, 0.75 if not broken else 0.48]:
        cyl((x, y + yc, z), 0.415, 0.415, 0.065, iron, 10)

def roofhalf(w, d, height, y, side, missing=False, burnt=False):
    rng = random.Random(49 + side)
    slope = math.degrees(math.atan2(height, w / 2))
    length = math.hypot(w / 2, height)
    for i, z in enumerate(np.arange(-d / 2 + 0.2, d / 2, 0.4)):
        if missing and (side == 1 and i in [1, 2, 3, 4] or (side == -1 and i in [6, 7])):
            continue
        col = black if burnt else roof if i % 3 else wooddark
        box((side * w / 4, y + height / 2, z), (length + 0.25, 0.14, 0.38), col, -side * slope, 'z')

def house(w, d, h, kind):
    burned = kind == 'burned'
    col = black if burned else wooddark
    wall = stone if kind == 'smith' else plaster
    box((0, 0.1, 0), (w, 0.2, d), stone)
    for side in [-1, 1]:
        x = side * (w / 4 + 0.5)
        box((x, h / 2, -d / 2), (w / 2 - 1, h, 0.18), wall)
    box((0, h - 0.35, -d / 2), (2, 0.7, 0.18), wall)
    if kind in ['large', 'smith']:
        box((w / 2, h / 2, 0), (0.18, h, d), wall)
    else:
        box((w / 2, 0.5, 0), (0.18, 1, d), wall)
        for z in [-d / 2 + 0.55, d / 2 - 0.55]:
            box((w / 2, h / 2, z), (0.18, h, 1.1), wall)
        box((w / 2, h - 0.35, 0), (0.18, 0.7, d - 2.2), wall)
    box((-w / 2, 0.42, 0), (0.2, 0.84, d), wall)
    box((-w / 2, 1.05, d * 0.28), (0.2, 2.1, d * 0.44), wall)
    box((0, h * 0.42, d / 2), (w, h * 0.84, 0.18), wall)
    for x, z in [(-w / 2, -d / 2), (w / 2, -d / 2), (w / 2, d / 2), (-w / 2, d / 2)]:
        box((x, h / 2, z), (0.22, h, 0.22), col)
    for z in [-d / 2, d / 2]:
        box((0, 0.22, z), (w + 0.2, 0.2, 0.22), col)
        box((0, h, z), (w + 0.2, 0.22, 0.24), col)
        for x in [-1.1, 1.1]:
            box((x, h / 2, z), (0.13, h, 0.2), col)
    rise = w * 0.35
    if not burned:
        for z in [-d / 2, d / 2]:
            rod((-w / 2, h, z), (0, h + rise, z), 0.1, col)
            rod((0, h + rise, z), (w / 2, h, z), 0.1, col)
        roofhalf(w + 0.5, d + 0.5, rise, h, -1, kind not in ['large', 'smith'])
        roofhalf(w + 0.5, d + 0.5, rise, h, 1, True)
        box((0, h + rise, 0), (0.18, 0.18, d + 0.7), col)
    else:
        rod((-w / 2, h, -d / 2), (0, h + rise * 0.6, -d / 2), 0.1, col)
        box((0.3, 0.35, 0), (w * 0.8, 0.2, 0.28), black, 28)
    for x in [-w / 2 + 0.7, w / 2 - 0.65]:
        box((x, h * 0.65, -d / 2 - 0.14), (0.72, 0.84, 0.1), wood, 8 if x < 0 else -13, 'z')
    stones(9, 7, (w * 0.75, d * 0.65), offset=(0, 0.2, 0))
    box((-0.8, 0.4, 0.3), (2, 0.16, 0.22), col, 24)
    if kind == 'smith':
        box((w / 2 + 0.65, 1.2, d / 2 - 0.6), (1.2, 2.4, 1.2), stone)
        box((w / 2 + 0.65, 2.7, d / 2 - 0.6), (0.8, 1, 0.8), stone)
    if kind == 'large':
        box((-0.9, 0.65, d / 2 + 0.3), (1.4, 1.3, 0.45), wood)
oldsave = save

def save(name, theme, role='decoration', label=None):
    oldsave(name, theme, role, label)
    a = assets[-1]
    old = R / a['path']
    new = R / 'assets/world_expansion' / theme / old.name
    new.parent.mkdir(parents=True, exist_ok=True)
    old.replace(new)
    a['path'] = new.relative_to(R).as_posix()
    if theme == 'cave' and any((k in name for k in ['crystal', 'glow', 'lava'])):
        j, b = read(new)
        for mat in j['materials']:
            c = mat['pbrMetallicRoughness']['baseColorFactor'][:3]
            if c in [list(cyan), list(purple), list(orange), [0.2, 0.7, 0.25]]:
                mat['emissiveFactor'] = c
        write(new, j, b)

def floor(col=stone):
    box((0, -0.1, 0), (4, 0.2, 4), col)

def ring(radius, h, thickness, col, n=16, broken=False, center=(0, 0, 0)):
    x, y, z = center
    for k in range(n):
        if broken and k in [0, 1, 2, 3, 4]:
            continue
        a = 2 * math.pi * k / n
        b = 2 * math.pi * (k + 1) / n
        v = [[x + r * math.cos(t), y + yy, z + r * math.sin(t)] for yy in [0, h] for r, t in [(radius - thickness, a), (radius, a), (radius, b), (radius - thickness, b)]]
        poly(v, [[0, 3, 2, 1], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]], col)

def crenels(length=4, h=3.5):
    for x in np.arange(-length / 2 + 0.3, length / 2, 0.8):
        box((x, h + 0.28, 0), (0.55, 0.56, 0.6), stonebright)

def castlewall(broken=False):
    if not broken:
        box((0, 1.75, 0), (4, 3.5, 0.6), stone)
        box((0, 3.5, 0), (4, 0.14, 0.75), stonebright)
        crenels()
    else:
        for x, h, w in [(-1.5, 2.7, 1), (-0.6, 0.75, 0.8), (0.45, 0.4, 1.1), (1.55, 3.1, 0.9)]:
            box((x, h / 2, 0), (w, h, 0.65), stone)
        stones(3, 9, (3.5, 1.8))
        box((-1.5, 2.98, 0), (0.6, 0.5, 0.75), stonebright)

def tower(broken=False, r=2.4, h=6):
    cyl((0, -0.1, 0), r, r, 0.2, stone, 16)
    if broken:
        ring(r, h * 0.55, 0.4, stone, 16, True)
    else:
        ring(r, 2.4, 0.4, stone, 16, True)
        ring(r, h - 2.4, 0.4, stone, 16, False, center=(0, 2.4, 0))
    if not broken:
        cyl((0, h - 0.18, 0), r - 0.35, r - 0.35, 0.18, stonebright, 16)
        for k in range(12):
            t = k * math.pi / 6
            box(((r - 0.15) * math.cos(t), h + 0.35, (r - 0.15) * math.sin(t)), (0.55, 0.7, 0.6), stonebright, -t * 180 / math.pi)
    else:
        stones(20, 12, (r * 1.8, r * 1.8))

def keep(broken=False):
    box((0, 0.1, 0), (8, 0.2, 8), stone)
    if not broken:
        for x in [-2.75, 2.75]:
            box((x, 3, -4), (2.5, 6, 0.4), stone)
        box((0, 4.2, -4), (3, 3.6, 0.4), stone)
        for x in [-4, 4]:
            box((x, 3, 0), (0.4, 6, 8), stone)
        box((0, 3, 4), (8, 6, 0.4), stone)
        box((0, 6, 0), (8.4, 0.25, 8.4), stonebright)
        for z in [-4, 4]:
            for x in np.arange(-3.8, 4, 0.9):
                box((x, 6.4, z), (0.6, 0.8, 0.6), stonebright)
        for x in [-4, 4]:
            for z in np.arange(-3.8, 4, 0.9):
                box((x, 6.4, z), (0.6, 0.8, 0.6), stonebright)
    else:
        box((-4, 1.8, 0), (0.45, 3.6, 8), stone)
        box((0, 2.5, 4), (8, 5, 0.45), stone)
        for x in [-3, -1.5, 1.5, 3]:
            box((x, 0.6, -4), (1.2, 1.2, 0.5), stone)
        for k in range(4):
            box((-2 + k * 1.1, 2.4 - k * 0.45, 2), (3, 0.3, 0.8), wooddark, k * 14, 'z')
        stones(18, 25, (7, 7))
        rock((2, 0.3, 3), (2, 0.6, 2), moss, 9)

def mineframe(broken=False):
    for x in [-1.6, 1.6]:
        box((x, 1.5, 0), (0.25, 3, 0.25), wooddark, 12 if broken and x > 0 else 0, 'z')
    box((0, 3, 0), (3.8, 0.3, 0.3), wood, -12 if broken else 0, 'z')
    for x in [-1.2, 1.2]:
        box((x, 2.6, 0), (0.18, 0.95, 0.18), wood, -35 if x > 0 else 35, 'z')

def rail(curved=False, junction=False):
    for z in np.arange(-1.8, 2, 0.45):
        box((0, 0.055, z), (1.6, 0.11, 0.18), wood)
    for x in [-0.55, 0.55]:
        if not curved:
            box((x, 0.14, 0), (0.09, 0.1, 4), iron)
        else:
            for k in range(10):
                a = k * math.pi / 20
                b = (k + 1) * math.pi / 20
                rr = 2 + x
                rod((-2 + rr * math.cos(a), 0.14, -2 + rr * math.sin(a)), (-2 + rr * math.cos(b), 0.14, -2 + rr * math.sin(b)), 0.05, iron)
    if junction:
        for x in [-0.55, 0.55]:
            box((0, 0.16, x), (4, 0.1, 0.09), iron)

def minecart(full=False):
    box((0, 0.32, 0), (1.2, 0.15, 1.7), iron)
    for x in [-0.6, 0.6]:
        box((x, 0.74, 0), (0.12, 0.75, 1.8), iron)
    for z in [-0.85, 0.85]:
        box((0, 0.74, z), (1.2, 0.75, 0.12), iron)
    for x in [-0.72, 0.72]:
        for z in [-0.55, 0.55]:
            rod((x - 0.06, 0.23, z), (x + 0.06, 0.23, z), 0.23, wooddark, 10)
    if full:
        stones(4, 14, (1, 1.4), offset=(0, 0.5, 0))

def chest():
    box((0, 0.38, 0), (1.2, 0.75, 0.8), wood)
    for x in [-0.4, 0.4]:
        box((x, 0.42, 0), (0.11, 0.86, 0.87), iron)
    box((0, 0.45, -0.44), (0.2, 0.24, 0.06), gold)

def ladder():
    for x in [-0.38, 0.38]:
        box((x, 1.5, 0), (0.09, 3, 0.09), wood)
    for y in np.arange(0.2, 3, 0.3):
        box((0, y, 0), (0.8, 0.065, 0.09), woodlight)

def crystal(col):
    for k in range(5):
        x = (k % 3 - 1) * 0.32
        z = (k // 3 - 0.5) * 0.38
        h = 0.6 + k % 3 * 0.4
        cyl((x, h / 2, z), 0.16, 0.12, h * 0.75, col, 6)
        cyl((x, h * 0.87, z), 0.12, 0, h * 0.25, col, 6)

def skull(c=(0, 0, 0)):
    x, y, z = c
    rock((x, y + 0.17, z), (0.38, 0.34, 0.31), cream, 9)
    for xx in [-0.09, 0.09]:
        box((x + xx, y + 0.19, z + 0.14), (0.08, 0.08, 0.015), black)
    box((x, y + 0.035, z + 0.07), (0.18, 0.07, 0.15), cream)
for typ in ['brick_heap', 'plaster_heap', 'roof_tiles', 'charred_beams']:
    begin()
    if typ == 'brick_heap':
        for k in range(14):
            box(((k % 4 - 1.5) * 0.28, 0.12 + k // 4 * 0.1, (k % 3 - 1) * 0.3), (0.36, 0.18, 0.23), red, k * 19)
    elif typ == 'plaster_heap':
        stones(12, 17, (2, 2))
    elif typ == 'roof_tiles':
        for k in range(12):
            box(((k % 4 - 1.5) * 0.3, 0.06 + k // 4 * 0.045, (k % 3 - 1) * 0.2), (0.38, 0.04, 0.25), roof, k * 21)
    else:
        for k in range(8):
            box(((k % 3 - 1) * 0.4, 0.1 + k * 0.025, 0), (2, 0.15, 0.18), black, k * 27)
    save('village_' + typ, 'village', 'obstacle')
for typ in ['door_fallen', 'window_boarded', 'window_shattered']:
    begin()
    if typ == 'door_fallen':
        box((0, 0.08, 0), (1.3, 0.16, 2.1), wood)
        box((0, 0.18, 0.6), (1.3, 0.08, 0.12), iron)
    else:
        for x in [-0.6, 0.6]:
            box((x, 0.8, 0), (0.12, 1.6, 0.15), wood)
        for y in [0.06, 1.55]:
            box((0, y, 0), (1.3, 0.12, 0.15), wood)
        if typ == 'window_boarded':
            for y in [0.4, 0.8, 1.2]:
                box((0, y, 0.1), (1.5, 0.18, 0.1), woodlight, 12, 'z')
        else:
            box((0, 0.8, 0), (0.08, 1.6, 0.12), wood, -18, 'z')
    save('village_' + typ, 'village', 'obstacle')
for name, h in [('dead_tree_large', 4), ('dead_tree_small', 2.4)]:
    begin()
    cyl((0, h / 2, 0), 0.25, 0.07, h, wooddark, 7)
    for side in [-1, 1]:
        rod((0, h * 0.6, 0), (side * h * 0.32, h * 0.92, 0.15), 0.055, wooddark)
        rod((side * h * 0.25, h * 0.85, 0.15), (side * h * 0.38, h * 0.84, 0.5), 0.025, wooddark)
    save('village_' + name, 'village', 'obstacle')
begin()
house(6, 4, 2.5, 'burned')
save('village_collapsed_workshop', 'village', 'wall')
begin()
box((0, 0.08, 0), (4, 0.16, 3), stone)
for x in [-1.8, 1.8]:
    box((x, 1.1, 0), (0.18, 2.2, 0.18), black)
box((0, 1.6, 0), (4, 0.18, 0.2), black, 18, 'z')
stones(39, 12, (3, 2))
save('village_shed_frame', 'village', 'wall')
begin()
ring(0.95, 0.65, 0.2, stone, 10, True)
rod((-0.95, 0.4, 0), (-0.9, 1.5, 0), 0.06, wood)
rod((0.9, 0.3, 0.2), (0, 0.1, 0.8), 0.06, wood)
save('village_well_collapsed', 'village', 'obstacle')
begin()
for x in [-1, 1]:
    box((x, 1.5, 0), (0.16, 3, 0.16), wood)
for y in [0.7, 1.7, 2.7]:
    box((0, y, 0), (2.8, 0.12, 0.14), wood, 10 if y == 1.7 else 0, 'z')
box((0, 2.4, 0.1), (2.8, 0.12, 0.8), woodlight, -12, 'z')
save('village_scaffold_broken', 'village', 'wall')
begin()
for k in range(6):
    bag(((k % 3 - 1) * 0.42, k // 3 * 0.33, 0), earth)
save('village_sandbag_barricade', 'village', 'obstacle')
begin()
box((0, 0.55, 0), (3, 0.14, 0.8), wooddark)
for k in range(5):
    box((k * 0.5 - 1, 0.95, 0), (0.15, 1.5, 0.15), wood, -15 + k * 8, 'z')
save('village_palisade_broken', 'village', 'wall')
begin()
tower(True, 1.8, 4)
save('village_watchtower_ruined', 'village', 'wall')
begin()
floor((0.28, 0.3, 0.31))
stones(5, 8, (3.7, 3.7), offset=(0, -0.18, 0))
save('cave_floor_rough', 'cave', 'walkable')
for typ in ['straight', 'corner', 'low']:
    begin()
    for x in [-1.5, -0.5, 0.5, 1.5]:
        rock((x, 1.1, 0), (1.5, 2.2 if typ == 'low' else 3.2, 1.1), stone, int((x + 2) * 3))
    if typ == 'corner':
        for z in [0.7, 1.7]:
            rock((1.5, 1.6, z), (1.1, 3.2, 1.5), stone, 9)
    save('cave_wall_' + typ, 'cave', 'wall')
begin()
arch(5, 4, 1.2, stone)
for x in [-2.4, 2.4]:
    rock((x, 1.6, 0), (1.1, 3.6, 1.8), stone, 12)
save('cave_entrance_arch', 'cave', 'wall')
for typ in ['stalagmites', 'stalactites', 'column']:
    begin()
    if typ == 'column':
        cyl((0, 1.6, 0), 0.55, 0.4, 3.2, stone, 7)
    else:
        for k in range(5):
            h = 0.6 + k % 3 * 0.6
            y = h / 2 if typ == 'stalagmites' else -h / 2
            cyl(((k % 3 - 1) * 0.45, y, (k // 3 - 0.5) * 0.5), 0.25 if typ == 'stalagmites' else 0, 0 if typ == 'stalagmites' else 0.25, h, stone, 7)
    save('cave_' + typ, 'cave', 'obstacle')
for n, c in [('cyan', cyan), ('violet', purple), ('green', (0.2, 0.7, 0.25))]:
    begin()
    crystal(c)
    save('cave_crystal_' + n, 'cave', 'obstacle')
for typ in ['mushroom_large', 'mushroom_cluster']:
    begin()
    for k in range(1 if typ == 'mushroom_large' else 5):
        x = (k % 3 - 1) * 0.4
        z = (k // 3 - 0.5) * 0.4
        h = 1.2 if typ == 'mushroom_large' else 0.45 + 0.1 * (k % 2)
        cyl((x, h / 2, z), h * 0.07, h * 0.05, h, cream, 7)
        cyl((x, h, z), h * 0.4, h * 0.13, h * 0.2, purple, 10)
    save('cave_glow_' + typ, 'cave', 'decoration')
for typ, col in [('pool', cyan), ('lava_pool', orange)]:
    begin()
    cyl((0, -0.03, 0), 1.5, 1.5, 0.06, col, 14)
    for k in range(10):
        t = k * math.pi / 5
        rock((math.cos(t) * 1.5, 0.1, math.sin(t) * 1.5), (0.6, 0.35, 0.6), stone, k)
    save('cave_' + typ, 'cave', 'decoration')
begin()
box((0, 0.25, 0), (4, 0.5, 1.8), stone)
box((0, 0.52, 0), (4, 0.05, 1.85), stonebright)
save('cave_natural_bridge', 'cave', 'walkable')
begin()
skull()
for k in range(5):
    rod((-0.7 + k * 0.3, 0.05, -0.2), (-0.55 + k * 0.3, 0.08, 0.45), 0.035, cream)
save('cave_bones_pile', 'cave', 'decoration')
begin()
for k in range(6):
    t = k * math.pi / 3
    rod((0, 0, 0), (math.cos(t) * 1.3, math.sin(t) * 1.3, 0), 0.008, cream, 4)
for rr in [0.45, 0.85, 1.2]:
    for k in range(6):
        a = k * math.pi / 3
        b = (k + 1) * math.pi / 3
        rod((math.cos(a) * rr, math.sin(a) * rr, 0), (math.cos(b) * rr, math.sin(b) * rr, 0), 0.008, cream, 4)
save('cave_web_frame', 'cave', 'decoration')
begin()
floor(stonebright)
for i in range(4):
    for k in range(4):
        box((i - 1.5, 0.025, k - 1.5), (0.94, 0.05, 0.94), stone if (i + k) % 3 == 0 else stonebright)
save('castle_floor_flagstone', 'castle_intact', 'walkable')
begin()
castlewall()
save('castle_wall_crenellated', 'castle_intact', 'wall')
begin()
castlewall()
box((1.7, 1.75, 1.7), (0.6, 3.5, 4), stone)
save('castle_wall_corner', 'castle_intact', 'wall')
begin()
arch(4, 4.2, 0.7, stone)
crenels(4, 4.2)
save('castle_gate_arch', 'castle_intact', 'wall')
begin()
for x in np.arange(-1.4, 1.41, 0.28):
    box((x, 1.6, 0), (0.07, 3.2, 0.08), iron)
for y in [0.25, 1, 1.75, 2.5, 3.15]:
    box((0, y, 0), (3, 0.07, 0.08), iron)
save('castle_portcullis', 'castle_intact', 'wall')
begin()
tower()
save('castle_tower_round', 'castle_intact', 'wall')
begin()
keep()
save('castle_keep', 'castle_intact', 'wall')
begin()
box((0, -0.1, 0), (4, 0.2, 2.8), stonebright)
for z in [-1.3, 1.3]:
    box((0, 0.5, z), (4, 1, 0.16), stone)
save('castle_wallwalk', 'castle_intact', 'walkable')
begin()
for k in range(12):
    h = (k + 1) * 0.2
    box((0, h / 2, -1.85 + k * 0.34), (2, h, 0.34), stone)
save('castle_stairs_2m', 'castle_intact', 'walkable')
begin()
box((0, 0.22, 0), (1.5, 0.44, 1.5), stonebright)
box((0, 0.85, 0.5), (1.4, 1.5, 0.2), gold)
box((0, 0.6, 0), (1.1, 0.35, 1), red)
for x in [-0.62, 0.62]:
    box((x, 0.85, 0), (0.15, 0.85, 1.2), gold)
save('castle_throne', 'castle_intact', 'furniture')
for typ, col in [('navy', (0.12, 0.22, 0.38)), ('red', red)]:
    begin()
    box((0, 1.5, 0), (0.07, 3, 0.07), iron)
    box((0.62, 2.3, 0), (1.3, 1.3, 0.04), col)
    box((0.62, 2.3, 0.04), (0.1, 0.7, 0.02), gold)
    save('castle_banner_' + typ, 'castle_intact', 'decoration')
begin()
for x in [-0.9, 0.9]:
    box((x, 0.7, 0), (0.13, 1.4, 0.3), wood)
box((0, 1, 0), (2, 0.13, 0.2), wood)
for x in [-0.6, 0, 0.6]:
    box((x, 0.9, 0.12), (0.07, 1.4, 0.05), iron)
    box((x, 0.38, 0.12), (0.4, 0.07, 0.07), gold)
save('castle_weapon_rack', 'castle_intact', 'obstacle')
begin()
box((0, 0.35, 0), (1.3, 0.7, 2.1), wood)
box((0, 0.77, 0), (1.2, 0.16, 2), cream)
box((0, 0.87, 0.3), (1.2, 0.05, 1.3), red)
save('castle_barracks_bed', 'castle_intact', 'furniture')
begin()
cyl((0, 0.9, 0), 0.12, 0.1, 1.8, wood, 8)
rock((0, 1.5, 0), (0.65, 0.85, 0.4), cream, 6)
rock((0, 2.16, 0), (0.34, 0.38, 0.3), cream, 8)
rod((-0.7, 1.65, 0), (0.7, 1.65, 0), 0.06, wood)
save('castle_training_dummy', 'castle_intact', 'obstacle')
begin()
box((0, 0.85, 0), (2, 0.14, 1.3), wood)
box((0, 0.96, 0), (1.5, 0.035, 1), cream)
for x in [-0.8, 0.8]:
    for z in [-0.5, 0.5]:
        box((x, 0.4, z), (0.15, 0.8, 0.15), wood)
save('castle_map_table', 'castle_intact', 'furniture')
begin()
cyl((0, 0.55, 0), 0.15, 0.1, 1.1, iron, 8)
cyl((0, 1.2, 0), 0.35, 0.5, 0.3, iron, 10)
for x in [-0.2, 0, 0.2]:
    cyl((x, 1.6, 0), 0.13, 0, 0.5, orange, 6)
save('castle_brazier', 'castle_intact', 'obstacle')
begin()
floor(stone)
for k in range(4):
    box((-0.8 + k * 0.5, 0.015, 0), (0.035, 0.025, 3), black, k * 7)
save('ruin_floor_cracked', 'castle_ruined', 'walkable')
begin()
castlewall(True)
save('ruin_wall_breached', 'castle_ruined', 'wall')
begin()
castlewall(True)
box((1.7, 0.55, 1.2), (0.5, 1.1, 2.4), stone)
stones(32, 7, (2, 2), offset=(1, 0, 1))
save('ruin_corner_broken', 'castle_ruined', 'wall')
begin()
arch(4, 4.2, 0.7, stone, True)
stones(49, 8, (3, 1.5))
save('ruin_gate_arch', 'castle_ruined', 'wall')
begin()
tower(True)
save('ruin_tower_halfcollapsed', 'castle_ruined', 'wall')
begin()
keep(True)
save('ruin_keep_collapsed', 'castle_ruined', 'wall')
begin()
for k in range(7):
    box(((k % 3 - 1) * 0.55, 0.12 + k * 0.03, 0), (0.6, 0.55, 0.7), stonebright, k * 23)
save('ruin_fallen_crenellations', 'castle_ruined', 'obstacle')
begin()
box((0, 1.3, 0), (0.08, 2.6, 0.08), wood)
poly([[0, 2.5, 0], [1.4, 2.5, 0], [1.2, 1.9, 0], [1.3, 1.6, 0], [0.8, 1.8, 0], [0.6, 1.3, 0], [0.3, 1.7, 0], [0, 1.5, 0]], [list(range(8)), list(range(7, -1, -1))], red)
save('ruin_banner_torn', 'castle_ruined', 'decoration')
begin()
box((0, 0.3, 0), (1.6, 0.6, 1.6), stone)
rock((0.5, 0.35, 1.5), (1, 0.7, 2.3), stonebright, 7)
rock((0.6, 0.4, 2.9), (0.7, 0.7, 0.7), stonebright, 10)
save('ruin_statue_fallen', 'castle_ruined', 'obstacle')
begin()
stones(15, 30, (4, 3))
save('ruin_siege_rubble', 'castle_ruined', 'obstacle')
begin()
for k in range(10):
    h = (k + 1) * 0.2
    box((-0.25 if k == 6 else 0, h / 2, -1.8 + k * 0.4), (1.5 if k == 6 else 2, h, 0.39), stone)
save('ruin_stairs_damaged', 'castle_ruined', 'walkable')
begin()
for x in [-2, 2]:
    box((x, 0.45, 0), (2, 0.9, 2), stone)
for x in [-3, 3]:
    box((x, 0.8, 0), (0.3, 1.6, 2.2), stone)
save('ruin_bridge_gap', 'castle_ruined', 'walkable')
begin()
ring(0.9, 1.4, 0.2, stone, 10, True)
rock((0.9, 0.1, 0), (0.7, 0.2, 0.5), moss, 3)
save('ruin_moss_column', 'castle_ruined', 'obstacle')
begin()
box((0, 0.5, 0), (2, 1, 0.5), stone)
for x in [-0.7, 0.5]:
    rock((x, 0.85, 0.32), (0.8, 0.2, 0.3), moss, 5)
save('ruin_moss_cover', 'castle_ruined', 'obstacle')
begin()
floor(earth)
stones(13, 12, (3.8, 3.8), offset=(0, -0.12, 0))
save('mine_floor_gravel', 'mine', 'walkable')
begin()
for x in [-1.5, -0.5, 0.5, 1.5]:
    rock((x, 1.4, 0), (1.4, 3.0, 1), stone, 20)
mineframe()
save('mine_wall_supported', 'mine', 'wall')
for typ in ['intact', 'broken']:
    begin()
    mineframe(typ == 'broken')
    save('mine_support_' + typ, 'mine', 'wall')
for typ in ['straight', 'corner', 'junction']:
    begin()
    rail(typ == 'corner', typ == 'junction')
    save('mine_rail_' + typ, 'mine', 'decoration')
for typ in ['empty', 'ore']:
    begin()
    minecart(typ == 'ore')
    save('mine_cart_' + typ, 'mine', 'obstacle')
for typ, col in [('iron', iron), ('copper', (0.62, 0.3, 0.12)), ('gold', gold)]:
    begin()
    rock((0, 0.5, 0), (1.2, 1, 1), stone, 28)
    for x, z in [(-0.3, 0.3), (0.2, 0.4), (0, -0.2)]:
        rock((x, 0.65, z), (0.45, 0.45, 0.4), col, 9)
    save('mine_ore_' + typ, 'mine', 'obstacle')
begin()
for x in np.arange(-1.9, 2, 0.25):
    box((x, 0.06, 0), (0.23, 0.12, 4), woodlight)
save('mine_platform_planks', 'mine', 'walkable')
begin()
for x in [-1.65, 1.65]:
    box((x, 0.03, 0), (0.7, 0.15, 4), wood)
for z in [-1.65, 1.65]:
    box((0, 0.03, z), (2.6, 0.15, 0.7), wood)
save('mine_shaft_open', 'mine', 'obstacle')
begin()
ladder()
save('mine_ladder_3m', 'mine', 'wall')
begin()
box((0, 0.07, 0), (2, 0.14, 2), iron)
box((0, 2.6, 0), (2, 0.14, 2), wood)
for x in [-0.9, 0.9]:
    for z in [-0.9, 0.9]:
        box((x, 1.3, z), (0.1, 2.6, 0.1), iron)
for x in [-0.9, 0.9]:
    for z in [-0.6, 0, 0.6]:
        box((x, 1.3, z), (0.05, 2.6, 0.05), iron)
save('mine_lift_cage', 'mine', 'wall')
begin()
box((0, 0.2, 0), (1.8, 0.4, 1.5), wood)
for z in [-0.7, 0.7]:
    box((0, 0.55, z), (1.8, 0.7, 0.1), wood)
stones(8, 12, (1.5, 1.2), offset=(0, 0.35, 0))
save('mine_ore_bin', 'mine', 'obstacle')
begin()
box((0, 0.24, 0), (0.9, 0.48, 0.5), wooddark)
box((0, 0.52, 0), (0.4, 0.08, 0.12), iron)
save('mine_toolbox', 'mine', 'obstacle')
begin()
box((0, 0.6, 0), (0.07, 1.2, 0.07), wood)
box((0, 1.2, 0), (0.8, 0.1, 0.1), iron, 10, 'z')
save('mine_pickaxe', 'mine', 'hand_equipment')
for typ in ['stone', 'sunken']:
    begin()
    floor(stone)
    for x in [-1.5, -0.5, 0.5, 1.5]:
        for z in [-1.5, -0.5, 0.5, 1.5]:
            if typ == 'sunken' and abs(x) < 1 and (abs(z) < 1):
                continue
            box((x, 0.025, z), (0.95, 0.05, 0.95), stonebright)
    save('dungeon_floor_' + typ, 'dungeon', 'walkable')
begin()
box((0, 1.5, 0), (4, 3, 0.35), stone)
for y in [0.1, 2.95]:
    box((0, y, 0), (4, 0.18, 0.5), stonebright)
save('dungeon_wall', 'dungeon', 'wall')
begin()
box((0, 1.5, 0), (4, 3, 0.35), stone)
box((1.8, 1.5, 1.8), (0.35, 3, 4), stone)
save('dungeon_corner', 'dungeon', 'wall')
begin()
arch(4, 3.7, 0.45, stone)
save('dungeon_door_arch', 'dungeon', 'wall')
begin()
for x in np.arange(-0.7, 0.71, 0.2):
    box((x, 1.15, 0), (0.055, 2.3, 0.06), iron)
for y in [0.1, 1.1, 2.25]:
    box((0, y, 0), (1.6, 0.07, 0.07), iron)
save('dungeon_cell_door', 'dungeon', 'wall')
begin()
for x in np.arange(-1.9, 2, 0.2):
    if abs(x) < 0.8:
        continue
    box((x, 1.5, 0), (0.06, 3, 0.06), iron)
box((0, 2.85, 0), (4, 0.14, 0.12), iron)
save('dungeon_cell_front', 'dungeon', 'wall')
begin()
box((0, 0.23, 0), (0.9, 0.46, 1.8), wooddark)
box((0, 0.49, 0), (0.85, 0.08, 1.7), earth)
save('dungeon_cell_bed', 'dungeon', 'furniture')
begin()
chest()
save('dungeon_treasure_chest', 'dungeon', 'obstacle')
begin()
floor(wooddark)
for x in [-1.5, -0.75, 0, 0.75, 1.5]:
    for z in [-1.5, -0.75, 0, 0.75, 1.5]:
        cyl((x, 0.35, z), 0.09, 0, 0.7, iron, 5)
save('dungeon_spike_trap', 'dungeon', 'hazard')
begin()
box((0, 0.04, 0), (1.4, 0.08, 1.4), iron)
box((0, 0.1, 0), (1.15, 0.06, 1.15), stonebright)
save('dungeon_pressure_plate', 'dungeon', 'walkable')
begin()
box((0, 0.25, 0), (0.45, 0.5, 0.4), stone)
rod((0, 0.48, 0), (0.3, 0.9, 0), 0.045, iron)
rock((0.3, 0.9, 0), (0.16, 0.16, 0.16), red, 9)
save('dungeon_lever', 'dungeon', 'obstacle')
begin()
cyl((0, 0.5, 0), 0.7, 0.5, 1, stone, 10)
cyl((0, 1.1, 0), 0.45, 0.3, 0.2, purple, 8)
save('dungeon_rune_pedestal', 'dungeon', 'obstacle')
begin()
box((0, 0.5, 0), (1.3, 1, 2.4), stone)
for x in [-0.58, 0.58]:
    box((x, 0.56, 0), (0.12, 0.9, 2.4), stonebright)
box((0, 1.02, 0), (1.25, 0.1, 2.3), black)
save('dungeon_sarcophagus_base', 'dungeon', 'obstacle')
begin()
box((0, 0.15, 0), (1.45, 0.3, 2.5), stonebright)
rock((0, 0.37, 0), (0.75, 0.2, 1.8), stone, 6)
save('dungeon_sarcophagus_lid', 'dungeon', 'obstacle')
begin()
box((0, 0.15, 0), (2, 0.3, 1.2), stone)
box((0, 0.85, 0), (1.8, 0.2, 1.0), stonebright)
for x in [-0.65, 0.65]:
    box((x, 0.5, 0), (0.2, 1, 0.2), stone)
skull((0, 0.95, 0))
save('dungeon_altar', 'dungeon', 'obstacle')
begin()
box((0, 1.5, 0), (4, 3, 0.35), stone)
for x in [-0.3, 0.3]:
    box((x, 1.5, 0.2), (0.07, 0.7, 0.025), purple, 25 if x < 0 else -25, 'z')
save('dungeon_secret_rune_wall', 'dungeon', 'wall')
begin()
for x in [-0.5, 0.5]:
    for y in np.arange(0.2, 1.7, 0.2):
        ring(0.08, 0.05, 0.025, iron, 6, center=(x, y, 0))
save('dungeon_hanging_chains', 'dungeon', 'decoration')
shutil.rmtree(R / 'assets/village', ignore_errors=True)
(R / 'licenses').mkdir(exist_ok=True)
(R / 'licenses/CC0.txt').write_text('All new models and scripts in this pack are original procedural geometry dedicated to CC0 1.0. https://creativecommons.org/publicdomain/zero/1.0/\nThese are custom complements, not official KayKit or Kenney assets. No third-party textures or meshes used.\n')
(R / 'catalog.json').write_text(json.dumps(assets, indent=2))
print('Built', len(assets), 'new GLBs:', {k: sum((a['category'] == k for a in assets)) for k in sorted({a['category'] for a in assets})})
