DND — WELTEN-ERWEITERUNG
102 NEUE LOW-POLY-MODELLE · GODOT 4.3 · CC0

Eigenständige Erweiterung zum bisherigen Dorf-/Höhlenpaket. Alle Modelle neu gebaut; die älteren ZIPs bleiben unverändert. 102 GLBs, 88 vorbereitete statische Kollisionsszenen, sechs zusammengesetzte Beispielszenen, Übersichten und editierbare Generatorquelle.

INHALT
Kaputtes Dorf — 16 Modelle: Ziegel-/Putz-/Dachziegel-/Brandtrümmer, gefallene Tür, verbarrikadiertes Fenster, kaputtes Fenster, zwei tote Bäume, eingestürzte Werkstatt, Schuppenrahmen, eingestürzter Brunnen, beschädigtes Gerüst, Sandsackbarrikade, kaputte Palisade, zerstörter Wachturm.
Höhle — 18 Modelle: rauer Boden, drei Felswandmodule, Eingangsbogen, Stalagmiten, Stalaktiten, Felssäule, drei Kristallgruppen mit Emission, großer Pilz und Pilzgruppe, Wasserbecken, Lavabecken, Naturbrücke, Knochenhaufen, Spinnennetz als dünnes Mesh.
Intakte Burg — 17 Modelle: Plattenboden, Zinnenmauer, Mauerecke, Torbogen, Fallgatter, runder Turm, Bergfried, Wehrgang, Treppe, Thron, zwei Banner, Waffenständer, Bett, Trainingspuppe, Kartentisch, Kohlenbecken.
Burgruine — 14 Modelle: rissiger Boden, durchbrochene Mauer, kaputte Ecke, gebrochener Torbogen, halber Turm, eingestürzter Bergfried, gefallene Zinnen, zerrissenes Banner, gefallene Statue, Belagerungstrümmer, beschädigte Treppe, unterbrochene Brücke, bemooste Säule und Deckung.
Mine — 19 Modelle: Kiesboden, gestützte Felswand, zwei Holzstützen, gerade/gebogene/gekreuzte Schienen, leere/gefüllte Lore, Eisen-/Kupfer-/Goldvorkommen, Holzplattform, offener Schachtkragen, Leiter, Förderkorb, Erzbehälter, Werkzeugkasten, Spitzhacke.
Dungeon — 18 Modelle: zwei Bodenvarianten, Wand, Ecke, Türbogen, Zellentür, Zellenfront mit Türöffnung, Bett, Schatztruhe, Stachelfalle, Druckplatte, Hebel, Runensockel, Sarkophag-Basis und separater Deckel, Altar, Runenwand, hängende Ketten.

STARTEN & EINBAUEN
project.godot öffnen, Godot importieren lassen, F5. Oben lassen sich die sechs Bereiche auswählen. Maus/Finger ziehen verschiebt die Kamera, +/- zoomt, Links/Rechts dreht sie. Die Demo zeigt die statischen Umgebungen; sie enthält keine neue Party, Bewohner-KI oder Spiellogik.
assets/world_expansion: reine GLBs, eingebettete Materialien, ohne externe Texturabhängigkeiten.
scenes/assets: direkt platzierbare Wrapper, bei massiven Modellen mit statischer Kollision.
scenes/village.tscn, cave.tscn, castle_intact.tscn, castle_ruined.tscn, mine.tscn, dungeon.tscn: zusammengesetzte Beispiele.
catalog.json: Modellpfade, Szenenpfade, Rollen, Maße, Dreieckzahlen und Materialzahl.
layouts.json: alle Objektpositionen und Drehungen je Beispielszenario.
previews: Vorschauen der tatsächlichen Meshes.
Ordner assets/world_expansion und benötigte scenes/scripts ins vorhandene Spiel kopieren. Die project.godot dieser Demo nicht über die bestehende Projektdatei kopieren.

MASSE & AUSRICHTUNG
Eine Godot-Einheit = ein Meter. Standardboden 4 x 4 m, Y=0 ist die Oberseite. Wandmodule 4 m lang entlang X; um 90 Grad um Y drehen für Seitenwände. Burgmauern 3,5 m plus Zinnen. Torbögen haben echte Durchgänge. Runde Burgtürme haben einen offenen unteren Sektor als Einstieg und ein oberes Deck; Bergfried ca. 8 x 8 m, Dachhöhe ca. 6 m. Aufstieg ins Obergeschoss/auf den Wehrgang mit separaten Treppen bzw. eigener Navigation einrichten.
Schienen gerade entlang Z, Länge 4 m. Kurve: 90 Grad, Mittellinienradius 2 m; Drehung/Anschluss passend ausrichten. Die Bahnschwellen des Kurvenmodells sind stilisiert gerade angeordnet.
Stalaktiten: Ursprung an der Decke, Geometrie wächst in -Y; an die Deckenhöhe setzen.
Sarkophagdeckel: eigenes Modell, in der Dungeon-Demo bei Y=1,06 über der Basis. Fallgatter: eigenes Modell, zum Öffnen nach +Y verschieben. Brücke der Burgruine besitzt absichtlich eine echte Lücke.

FUNKTIONALE GRENZEN
Modelle sind statische Assets. Fallen verursachen nicht automatisch Schaden; Hebel, Druckplatten, Truhe, Fallgatter und Förderkorb brauchen Interaktions-/Animationslogik im Spiel. Separate Modelle erlauben eigene Bewegung. Die verborgene Runenwand ist eine vollständige Wand, die dein Spiel bei Bedarf entfernen kann.
ConcavePolygonShape3D ist für statische Umgebung vorgesehen. Bewegliche Lore/Förderkorb/Gatter für Physik mit einfachen Box-/konvexen Collidern ergänzen; nicht den statischen Trimesh-Wrapper als dynamische Physik nutzen.
Dekorative Kristalle/Pilze/Becken/Netze/Ketten ohne Kollision, damit kleine Details die Bewegung nicht blockieren. Emissions-Materiale leuchten farbig; Bloom benötigt einen unterstützten Renderer, PointLights sind separat zu setzen. Lava-/Wasserbecken sind statische Oberflächen, keine Flüssigkeitssimulation.
Es werden keine NavigationRegion3D, Quests, Dialoge oder Gegner automatisch in dein vorhandenes Spiel eingebaut.

QUELLE & LIZENZ
Neue Geometrie und Scripts CC0 1.0; siehe licenses/CC0.txt. Eigene Ergänzungen, keine offiziellen KayKit-/Kenney-Assets. Keine fremden Texturen/Meshes im Archiv.
source/generate_models.py erzeugt alle Modelle mit Python + NumPy + Pillow. Vom Elternordner der DnD_World_Expansion aus starten; Zielordner ist DnD_World_Expansion. Nach Geometrieänderungen Kollisionen/Szenen entsprechend erneuern. Das Archiv ist ohne Python direkt in Godot nutzbar.

PRÜFUNG
Godot 4.3 headless: 102 GLBs und alle 102 Wrapper laden, 88 Trimesh-Kollisionen haben die erwartete Dreieckzahl; alle sechs Beispielszenen laden. Bodenunterstützung je Szene geprüft. Separater Schacht-Test: Mittelpunkt frei, Rand trägt.
Beim Freigeben der Beispielszenen meldet der Dummy-Renderer mesh_get_surface_count: 'Parameter m is null'. Ressourcen-, Physics- und Szeneprüfungen bestehen. Grafik, Glow und Leistung auf deinem Android-Gerät sind noch nicht geprüft.
