extends CharacterBody3D
@export var actor_role: String = "neutral_npc"
var animation_player: AnimationPlayer

func _ready() -> void:
	find_player($Visual)
	play_action("idle")

func find_player(node: Node) -> void:
	if node is AnimationPlayer:
		animation_player = node
	for child in node.get_children():
		find_player(child)

func play_action(action: String) -> bool:
	if animation_player == null:
		return false
	var choices: Array = []
	match action:
		"idle": choices = ["Idle"]
		"walk": choices = ["Walk", "Walking_A"]
		"run": choices = ["Run", "Running_A"]
		"attack": choices = ["Attack", "1H_Melee_Attack_Chop"]
		"slam": choices = ["Slam", "2H_Melee_Attack_Chop"]
		"cast": choices = ["Cast", "Spellcast_Shoot"]
		"hit": choices = ["Hit", "Hit_A"]
		"death": choices = ["Death", "Death_A"]
		"spawn": choices = ["Spawn"]
		"cheer": choices = ["Cheer", "Idle"]
		"interact": choices = ["Interact", "Use_Item", "Cast"]
		_: return false
	for candidate in choices:
		for clip in animation_player.get_animation_list():
			if str(clip).split("|")[-1] == candidate:
				animation_player.get_animation(clip).loop_mode = Animation.LOOP_LINEAR if action in ["idle", "walk", "run"] else Animation.LOOP_NONE
				animation_player.play(clip, 0.12)
				return true
	return false
