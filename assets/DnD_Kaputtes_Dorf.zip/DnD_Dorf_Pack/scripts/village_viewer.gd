extends Node3D
var center = Vector3.ZERO
var angle: float = 0.65
var zoom: float = 55.0
var drag = false
@onready var camera: Camera3D = $Camera3D

func _ready() -> void:
	var world = WorldEnvironment.new()
	var environment = Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("1c2932")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color(0.8, 0.85, 0.87)
	environment.ambient_light_energy = 0.75
	world.environment = environment
	add_child(world)
	# Animate only the blue water material; riverbank/rock materials remain unchanged.
	for child in get_children():
		if str(child.name).begins_with("river_") and not str(child.name).begins_with("river_bank_"):
			apply_water(child)
	var layer = CanvasLayer.new()
	add_child(layer)
	var box = VBoxContainer.new()
	box.position = Vector2(16, 16)
	layer.add_child(box)
	var title = Label.new()
	title.text = "Kaputtes Dorf — Flussübergang"
	box.add_child(title)
	var help = Label.new()
	help.text = "Ziehen: Kamera bewegen | Mausrad / +/-: Zoom"
	box.add_child(help)
	var row = HBoxContainer.new()
	box.add_child(row)
	for action in ["Links", "Rechts", "+", "-"]:
		var button = Button.new()
		button.text = action
		button.custom_minimum_size = Vector2(80, 48)
		button.pressed.connect(control.bind(action))
		row.add_child(button)
	var npc_row = HBoxContainer.new()
	box.add_child(npc_row)
	for action in ["idle", "walk", "interact", "hit"]:
		var button = Button.new()
		button.text = {"idle":"Warten", "walk":"Gehen", "interact":"Arbeiten", "hit":"Treffer"}[action]
		button.custom_minimum_size = Vector2(80, 48)
		button.pressed.connect(animate_residents.bind(action))
		npc_row.add_child(button)
	update_camera()

func apply_water(node: Node) -> void:
	if node is MeshInstance3D:
		for i in range(node.mesh.get_surface_count()):
			var material = node.mesh.surface_get_material(i)
			if material is StandardMaterial3D and material.albedo_color.b > 0.4 and material.albedo_color.r < 0.2:
				var water = ShaderMaterial.new()
				water.shader = preload("res://scripts/water.gdshader")
				node.set_surface_override_material(i, water)
	for child in node.get_children():
		apply_water(child)

func control(action: String) -> void:
	match action:
		"Links": angle -= 0.22
		"Rechts": angle += 0.22
		"+": zoom = max(12.0, zoom - 5.0)
		"-": zoom = min(85.0, zoom + 5.0)
	update_camera()

func animate_residents(action: String) -> void:
	for actor in get_tree().get_nodes_in_group("village_residents"):
		actor.play_action(action)

func update_camera() -> void:
	camera.size = zoom
	camera.position = center + Vector3(sin(angle) * 45, 40, cos(angle) * 45)
	camera.look_at(center)

func pan(relative: Vector2) -> void:
	center += (-camera.global_basis.x * relative.x + camera.global_basis.y * relative.y) * zoom / 720.0
	center.y = 0
	center.x = clamp(center.x, -25, 25)
	center.z = clamp(center.z, -20, 20)
	update_camera()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			drag = event.pressed
		if event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			control("+")
		if event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			control("-")
	elif event is InputEventMouseMotion and drag:
		pan(event.relative)
	elif event is InputEventScreenDrag:
		pan(event.relative)
