extends SceneTree
func _initialize() -> void:
	call_deferred("verify")
func verify() -> void:
	var catalog = JSON.parse_string(FileAccess.get_file_as_string("res://catalog.json"))
	var models = 0
	var collision_count = 0
	var residents = 0
	for entry in catalog:
		var resource = load("res://" + entry.path)
		assert(resource is PackedScene, entry.path)
		var instance = resource.instantiate()
		assert(instance != null)
		instance.free()
		models += 1
		var prepared = load("res://" + entry.scene).instantiate()
		assert(prepared != null)
		if entry.category == "residents":
			root.add_child(prepared)
			assert(prepared.animation_player != null)
			for action in ["idle", "walk", "interact", "hit", "death"]:
				assert(prepared.play_action(action), entry.id + ": " + action)
				prepared.animation_player.advance(0.2)
			residents += 1
		elif entry.get("collision_ready", false):
			assert(prepared.get_node("Body/CollisionShape3D").shape is ConcavePolygonShape3D)
			assert(prepared.get_node("Body/CollisionShape3D").shape.get_faces().size() > 0)
			collision_count += 1
		prepared.free()
	var village = load("res://scenes/Damaged_Village.tscn").instantiate()
	root.add_child(village)
	for i in range(3):
		await physics_frame
	assert(get_nodes_in_group("village_residents").size() == 8)
	# Main road and bridge support ray: center of each avoids rail geometry.
	for x in [-8.0, -4.0, 0.0, 4.0, 8.0]:
		var query = PhysicsRayQueryParameters3D.create(Vector3(x, 3, 0), Vector3(x, -1, 0), 1)
		var hit = village.get_world_3d().direct_space_state.intersect_ray(query)
		assert(not hit.is_empty(), "No support on crossing at " + str(x))
		print("Bridge ray ", x, " -> ", hit.position, " / ", hit.collider.name)
		if abs(x) <= 4:
			assert(hit.position.y > 0.3, "Bridge deck support missing")
	village.animate_residents("walk")
	for actor in get_nodes_in_group("village_residents"):
		actor.animation_player.advance(0.4)
	village.free()
	print("PASS: %d GLBs, %d static collision wrappers, %d animated residents; map loads and bridge supports all five ray probes." % [models, collision_count, residents])
	quit()
