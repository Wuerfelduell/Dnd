extends Node3D
@export var page: String = "Creatures"

func _ready() -> void:
	var layer = CanvasLayer.new()
	add_child(layer)
	var panel = PanelContainer.new()
	panel.position = Vector2(12, 12)
	layer.add_child(panel)
	var box = VBoxContainer.new()
	panel.add_child(box)
	var label = Label.new()
	label.text = "DnD — " + page
	box.add_child(label)
	var pages = HBoxContainer.new()
	box.add_child(pages)
	for name in ["Creatures", "Tavern_People"]:
		var button = Button.new()
		button.text = name
		button.custom_minimum_size = Vector2(150, 44)
		button.pressed.connect(change_page.bind(name))
		pages.add_child(button)
	var row = HBoxContainer.new()
	box.add_child(row)
	for action in ["idle", "walk", "run", "attack", "slam", "cast", "hit", "death", "spawn"]:
		var button = Button.new()
		button.text = action.capitalize()
		button.custom_minimum_size = Vector2(65, 44)
		button.pressed.connect(show_action.bind(action))
		row.add_child(button)

func change_page(name: String) -> void:
	get_tree().change_scene_to_file("res://scenes/cast_expansion/" + name + ".tscn")

func show_action(action: String) -> void:
	for actor in get_children():
		if actor.has_method("play_action") and not actor.play_action(action):
			actor.play_action("idle")
