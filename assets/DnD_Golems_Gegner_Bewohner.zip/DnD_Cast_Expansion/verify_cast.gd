extends SceneTree

func _initialize() -> void:
	call_deferred("verify")

func verify() -> void:
	var file = FileAccess.open("res://character_catalog.json", FileAccess.READ)
	var catalog = JSON.parse_string(file.get_as_text())
	for asset in catalog:
		var resource = load("res://" + asset.path)
		if not resource is PackedScene:
			push_error("Cannot load " + asset.path)
			quit(1)
			return
		var model = resource.instantiate()
		model.free()
		var actor = load("res://scenes/cast_expansion/actors/" + asset.name + ".tscn").instantiate()
		root.add_child(actor)
		for action in ["idle", "walk", "run", "attack", "cast", "hit", "death", "idle"]:
			if not actor.play_action(action):
				push_error(asset.name + " missing " + action)
				quit(1)
				return
			actor.animation_player.advance(0.25)
		if asset.rig_type == "animated rigid-part hierarchy":
			actor.play_action("death")
			actor.animation_player.advance(2.0)
			actor.play_action("idle")
			actor.animation_player.advance(0.3)
			if not actor.get_node("Visual").rotation.is_equal_approx(Vector3.ZERO):
				push_error(asset.name + " pose did not reset")
				quit(1)
				return
			for action in ["slam", "spawn"]:
				if not actor.play_action(action):
					quit(1)
					return
				actor.animation_player.advance(0.3)
		print("PASS actor/actions: ", asset.name)
		root.remove_child(actor)
		actor.free()
	for page in ["Creatures", "Tavern_People"]:
		var showcase = load("res://scenes/cast_expansion/" + page + ".tscn").instantiate()
		root.add_child(showcase)
		showcase.show_action("walk")
		showcase.show_action("idle")
		root.remove_child(showcase)
		showcase.free()
	print("PASS: 20 models and actor scenes, actions, custom pose reset and 2 viewers.")
	quit()
